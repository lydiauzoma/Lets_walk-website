"use strict";

// Include the app.js file.
// This will run the code.
console.log("entrypoint");
import app from "./src/app.js";